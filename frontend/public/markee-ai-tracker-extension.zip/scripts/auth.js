// ==========================================
// NHIỆM VỤ: Lấy định danh người dùng
// ==========================================
var currentUser = "Unknown";

function autoLogin() {
  chrome.runtime.sendMessage({ action: "GET_USER_EMAIL" }, (response) => {
    if (response && response.email) {
      currentUser = response.email;
      console.log(`[Markee] 🔐 Login tự động qua Google: ${currentUser}`);
    } else {
      chrome.storage.local.get(["markee_username"], function (result) {
        if (result.markee_username) {
          currentUser = result.markee_username;
        } else {
          currentUser = "Unknown";
          console.log('🟡 [WARN]', "[Markee] Không lấy được Email. Đang dùng Unknown.");
        }
      });
    }
  });
}
autoLogin();
