const SUPABASE_URL = "https://wqdmnntlnwxmoghtewxk.supabase.co";
const SUPABASE_KEY = "sb_publishable_JfB2QHWZLVRNcmx7aV2fKw_t-XD9YbH";
const HEARTBEAT_ALARM_NAME = "markee-heartbeat";
const HEARTBEAT_PERIOD_MINUTES = 3;
const VERSION_CHECK_ALARM_NAME = "checkMarkeeVersion";
const VERSION_CHECK_PERIOD_MINUTES = 30; // Cronjob định kỳ kiểm tra version mỗi 30 phút

// ==========================================
// HÀM TIỆN ÍCH: Uint8Array → Base64 an toàn cho file lớn
// Dùng chunk 32KB để tránh lỗi "Maximum call stack size exceeded"
// khi dùng String.fromCharCode.apply với mảng dữ liệu quá lớn
// ==========================================
function uint8ArrayToBase64(u8Arr) {
  const CHUNK_SIZE = 0x8000; // 32768 bytes mỗi lần
  let index = 0;
  const length = u8Arr.length;
  let result = "";
  while (index < length) {
    const slice = u8Arr.subarray(index, Math.min(index + CHUNK_SIZE, length));
    result += String.fromCharCode.apply(null, slice);
    index += CHUNK_SIZE;
  }
  return btoa(result);
}

// ==========================================
// CƠ CHẾ BẮT FILE TẢI VỀ TỪ TRANG AI (DOWNLOAD API)
// ==========================================
let lastAIFile = null;

chrome.downloads.onCreated.addListener((item) => {
  // Kiểm tra xem người dùng đang đứng ở tab nào
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || tabs.length === 0) return;
    const currentTab = tabs[0];
    const tabUrl = currentTab.url || "";

    // Nếu đang đứng ở trang AI thì bắt đầu hành động
    if (tabUrl.includes("claude.ai") || tabUrl.includes("chatgpt.com") || tabUrl.includes("gemini.google.com")) {
      const downloadUrl = item.url || "";
      const isChatGPT = downloadUrl.includes("chatgpt.com") || downloadUrl.includes("oaiusercontent");
      const delay = isChatGPT ? 200 : 20;

      console.log(`[Markee Background] 🔎 Phát hiện lệnh tải file: ${item.filename} | URL: ${downloadUrl} | Độ trễ: ${delay}ms`);

      setTimeout(() => {
        chrome.tabs.sendMessage(
          currentTab.id,
          {
            action: "FETCH_AI_BLOB",
            downloadUrl: item.url,
            rawFilename: item.filename,
          },
          (response) => {
            // Bắt lỗi nếu tab web chưa load xong tracker.js
            if (chrome.runtime.lastError) {
              console.log("🟡 [WARN]", "[Markee Background] ⚠️ Chưa thể kết nối tracker.js:", chrome.runtime.lastError.message);
              return;
            }

            if (response && response.success) {
              lastAIFile = response.file;
              console.log("[Markee Background] 📥 Đã bắt quả tang và ghim file AI:", lastAIFile.fileName);
            }
          },
        );
      }, delay);
    }
  });
});

function getUserEmail() {
  return new Promise((resolve) => {
    chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, (userInfo) => {
      resolve(userInfo?.email || "Unknown");
    });
  });
}

function getDeviceName() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["device_name"], (result) => {
      const deviceName = typeof result.device_name === "string" ? result.device_name.trim() : "";
      resolve(deviceName || "Unknown Device");
    });
  });
}

async function sendHeartbeat() {
  try {
    const [userEmail, deviceName] = await Promise.all([getUserEmail(), getDeviceName()]);
    if (!userEmail || userEmail === "Unknown") {
      throw new Error("Không có email người dùng để cập nhật ai_licenses.");
    }

    const payload = {
      last_active_device: deviceName,
      last_ping_at: new Date().toISOString(),
    };
    const encodedEmail = encodeURIComponent(userEmail);
    const activeStatuses = encodeURIComponent('in.(Active,"Hoạt động")');

    const response = await fetch(`${SUPABASE_URL}/rest/v1/ai_licenses?email=eq.${encodedEmail}&status=${activeStatuses}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        Prefer: "return=representation",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      throw new Error(`Heartbeat update ai_licenses rejected: ${response.status} ${detail}`);
    }
  } catch (err) {
    console.log("🔴 [ERROR]", "[Markee Background] Lỗi gửi Heartbeat:", err);
  }
}

function ensureHeartbeatAlarm() {
  chrome.alarms.create(HEARTBEAT_ALARM_NAME, {
    periodInMinutes: HEARTBEAT_PERIOD_MINUTES,
  });
}

function supabaseHeaders(prefer = "return=minimal") {
  return {
    "Content-Type": "application/json",
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    Prefer: prefer,
  };
}

// Bỏ đi, hàm uploadStagedFiles cũ không còn cần thiết vì đã gộp vào handleAutoLog

// ==========================================
// Backend: Auto Log Handler (2 bước)
// ==========================================
async function handleAutoLog(logData) {
  const stagedFiles = Array.isArray(logData.staged_files) ? logData.staged_files : [];

  console.log("[Markee Background] 🚀 Bắt đầu xử lý AUTO_LOG...");

  // ========== [BƯỚC 1] Tạo ai_sessions ==========
  console.log("[Markee Background] [Bước 1] Tạo ai_sessions...");
  const sessionPayload = {
    ai_tool: logData.ai_tool || "unknown",
    project_id: logData.project_id || null,
    team_track: logData.team_track || null,
    task_type: logData.task_type || "default",
    prompt_content: logData.prompt_content || "",
    tokens_used: logData.tokens_used || 0,
    author_id: logData.author_id,
  };

  let sessionId = null;
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/ai_sessions`, {
      method: "POST",
      headers: supabaseHeaders("return=representation"),
      body: JSON.stringify([sessionPayload]),
    });

    if (!response.ok) {
      const errDetail = await response.text().catch(() => "");
      throw new Error(`Supabase reject ai_sessions (${response.status}): ${errDetail}`);
    }

    const insertedSessions = await response.json().catch(() => []);
    sessionId = insertedSessions?.[0]?.id;

    if (!sessionId) {
      throw new Error("Không nhận được sessionId từ response ai_sessions");
    }

    console.log(`[Markee Background] ✅ Tạo ai_sessions thành công (sessionId: ${sessionId})`);
  } catch (err) {
    console.log("🔴 [ERROR]", "[Markee Background] ❌ Lỗi tạo ai_sessions:", err.message);
    throw err;
  }

  // ========== [BƯỚC 2] Upload staged files (Đã được FIX 404 & BULK) ==========
  if (stagedFiles && stagedFiles.length > 0 && sessionId) {
    console.log(`[Markee Background] [Bước 2] Upload ${stagedFiles.length} file(s)...`);

    try {
      const uploadPromises = stagedFiles.map(async (file) => {
        // Bỏ qua file 0 bytes
        if (!file.size || file.size === 0) {
          throw new Error("File rỗng (0 bytes)");
        }

        const safeFileName = String(file.fileName).replace(/[^a-zA-Z0-9.-]/g, "_");

        // 🔥 FIX LỖI 404: Tên file lưu DB chỉ gồm timestamp + tên gốc (KHÔNG có chat_attachments/)
        const uniqueFileName = `${Date.now()}_${safeFileName}`;

        // Decode base64 Data URL → Uint8Array (Service Worker không hỗ trợ fetch blob: URL)
        const base64String = file.base64.split(",")[1] || file.base64;
        const binaryStr = atob(base64String);
        const bytes = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);
        const blob = bytes;

        // 🔥 FIX LỖI 404: Lúc upload lên Storage thì mới ghép thư mục bucket vào URL
        const uploadUrl = `${SUPABASE_URL}/storage/v1/object/chat_attachments/${uniqueFileName}`;

        const uploadRes = await fetch(uploadUrl, {
          method: "POST",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
            "Content-Type": file.mimeType || "application/octet-stream",
          },
          body: blob,
        });

        if (!uploadRes.ok) {
          const detail = await uploadRes.text().catch(() => "");
          throw new Error(`Storage upload failed: ${detail}`);
        }

        // Trả về metadata để ghi vào DB (storage_path sạch sẽ)
        return {
          file_name: file.fileName,
          storage_path: uniqueFileName,
          mime_type: file.mimeType,
          size_bytes: file.size,
          session_id: sessionId,
        };
      });

      // Thực thi upload song song, thằng nào sống thì đi tiếp
      const results = await Promise.allSettled(uploadPromises);
      const successfulFiles = results.filter((r) => r.status === "fulfilled").map((r) => r.value);
      const failedFiles = results.filter((r) => r.status === "rejected");

      if (failedFiles.length > 0) {
        console.log("🟡 [WARN]", `[Markee Background] ⚠️ Có ${failedFiles.length} file bị rớt khi upload lên Storage.`);
      }

      console.log(`[Markee Background] ✅ ${successfulFiles.length}/${stagedFiles.length} file upload Storage thành công. Đang lưu DB...`);

      // Bulk Insert những file thành công vào database (1 lệnh POST duy nhất)
      if (successfulFiles.length > 0) {
        const dbRes = await fetch(`${SUPABASE_URL}/rest/v1/uploaded_files`, {
          method: "POST",
          headers: supabaseHeaders("return=minimal"),
          body: JSON.stringify(successfulFiles),
        });

        if (!dbRes.ok) {
          const errText = await dbRes.text().catch(() => "");
          console.log("🔴 [ERROR]", "[Markee Background] ❌ DB Insert Failed:", errText);
        } else {
          console.log(`[Markee Background] 🎉 Bulk INSERT ${successfulFiles.length} file(s) thành công!`);
        }
      }
    } catch (err) {
      console.log("🔴 [ERROR]", "[Markee Background] ❌ Lỗi luồng Upload File:", err.message);
    }
  } else {
    console.log("[Markee Background] ℹ️ Không có staged files hợp lệ để upload");
  }

  console.log("[Markee Background] ✅ AUTO_LOG hoàn thành!");
}

// ==========================================
// FEATURE 2: VERSION CHECKER
// - isNewerVersion: semver compare
// - checkExtensionVersion: fetches Supabase, caches result in chrome.storage.local
// - onUpdated listener: re-broadcasts cached update to AI tabs on F5 / new tab
// ==========================================

function isNewerVersion(remoteVersion, localVersion) {
  const parse = (v) =>
    String(v)
      .split(".")
      .map((n) => parseInt(n, 10) || 0);
  const remote = parse(remoteVersion);
  const local = parse(localVersion);
  const len = Math.max(remote.length, local.length);
  for (let i = 0; i < len; i++) {
    if ((remote[i] || 0) > (local[i] || 0)) return true;
    if ((remote[i] || 0) < (local[i] || 0)) return false;
  }
  return false;
}

async function checkExtensionVersion() {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/extension_version?is_active=eq.true&select=version_number,download_url&limit=1`, { method: "GET", headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });

    if (!res.ok) {
      console.log("\ud83d\udfe1 [VersionCheck] Supabase tr\u1ea3 l\u1ed7i:", res.status, res.statusText);
      return;
    }

    const rows = await res.json();
    if (!rows || rows.length === 0) {
      console.log("[VersionCheck] Kh\u00f4ng c\u00f3 b\u1ea3n ghi active trong extension_version.");
      return;
    }

    const { version_number: remoteVersion, download_url: downloadUrl } = rows[0];
    const localVersion = chrome.runtime.getManifest().version;
    console.log(`[VersionCheck] Local: ${localVersion} | Remote: ${remoteVersion}`);

    if (!isNewerVersion(remoteVersion, localVersion)) {
      console.log("[VersionCheck] \u2705 \u0110ang d\u00f9ng phi\u00ean b\u1ea3n m\u1edbi nh\u1ea5t.");
      chrome.storage.local.remove("markee_update_cache"); // Clear stale cache
      return;
    }

    // Persist to storage so the update badge survives Service Worker restarts and F5
    const updateData = { remoteVersion, downloadUrl: downloadUrl || "https://aiskill.markeeai.com" };
    chrome.storage.local.set({ markee_update_cache: updateData });
    console.log(`[VersionCheck] \ud83d\ude80 Ph\u00e1t hi\u1ec7n phi\u00ean b\u1ea3n m\u1edbi: ${remoteVersion}. Broadcast...`);

    // Broadcast to all currently open AI tabs
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        const url = tab.url || "";
        if (url.includes("chatgpt.com") || url.includes("claude.ai") || url.includes("gemini.google.com")) {
          chrome.tabs
            .sendMessage(tab.id, {
              action: "UPDATE_AVAILABLE",
              remoteVersion,
              localVersion,
              downloadUrl: updateData.downloadUrl,
            })
            .catch(() => {});
        }
      }
    });
  } catch (err) {
    console.log("\ud83d\udd34 [ERROR] [VersionCheck] L\u1ed7i ki\u1ec3m tra phi\u00ean b\u1ea3n:", err.message);
  }
}

// Re-broadcast cached update when an AI tab finishes loading (handles F5 / new tabs)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  const url = tab.url || "";
  if (!url.includes("chatgpt.com") && !url.includes("claude.ai") && !url.includes("gemini.google.com")) return;

  chrome.storage.local.get(["markee_update_cache"], (result) => {
    if (!result.markee_update_cache) return;
    const { remoteVersion, downloadUrl } = result.markee_update_cache;
    // Delay 1.5s to let content scripts finish injecting before we send the message
    setTimeout(() => {
      chrome.tabs
        .sendMessage(tabId, {
          action: "UPDATE_AVAILABLE",
          remoteVersion,
          localVersion: chrome.runtime.getManifest().version,
          downloadUrl,
        })
        .catch(() => {});
    }, 1500);
  });
});

function ensureVersionCheckAlarm() {
  chrome.alarms.create(VERSION_CHECK_ALARM_NAME, { periodInMinutes: VERSION_CHECK_PERIOD_MINUTES });
}

ensureHeartbeatAlarm();

chrome.runtime.onInstalled.addListener(() => {
  ensureHeartbeatAlarm();
  ensureVersionCheckAlarm();
  sendHeartbeat();
  checkExtensionVersion();
});

chrome.runtime.onStartup.addListener(() => {
  ensureHeartbeatAlarm();
  ensureVersionCheckAlarm();
  sendHeartbeat();
  checkExtensionVersion();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === HEARTBEAT_ALARM_NAME) {
    sendHeartbeat();
  }
  if (alarm.name === VERSION_CHECK_ALARM_NAME || alarm.name === "checkMarkeeVersion") {
    checkExtensionVersion();
  }
});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { action: "toggle_widget" }).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "CHECK_VERSION_MANUAL") {
    checkExtensionVersion()
      .then(() => {
        chrome.storage.local.get(["markee_update_cache"], (res) => {
          const update = res.markee_update_cache || null;
          sendResponse({ success: true, update });

          // Nếu KHÔNG có bản mới → Broadcast VERSION_UP_TO_DATE để UI ẩn chấm đỏ ngay lập tức
          if (!update) {
            chrome.tabs.query({}, (tabs) => {
              for (const tab of tabs) {
                const url = tab.url || "";
                if (url.includes("chatgpt.com") || url.includes("claude.ai") || url.includes("gemini.google.com")) {
                  chrome.tabs.sendMessage(tab.id, { action: "VERSION_UP_TO_DATE" }).catch(() => {});
                }
              }
            });
          }
        });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }

  if (message.action === "GET_USER_EMAIL") {
    chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, function (userInfo) {
      sendResponse({ email: userInfo?.email || null });
    });
    return true;
  }

  if (message.action === "AUTO_LOG") {
    handleAutoLog(message.data)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee Background] ❌ Lỗi luồng Push AUTO_LOG:", err.message);
        sendResponse({ ok: false, error: err.message });
      });
    return true;
  }

  if (message.action === "SAVE_SCRAPED_MARKDOWN") {
    // Sử dụng IIFE (Immediately Invoked Function Expression) để xử lý bất đồng bộ
    (async () => {
      let fileMetadata = null;

      // 1. XÁC ĐỊNH FILE ĐỂ UPLOAD: Ưu tiên lastAIFile (download click) → autoScrapedFiles (DOM scrape)
      const autoScrapedFiles = Array.isArray(message.autoScrapedFiles) ? message.autoScrapedFiles : [];
      const primaryFile = lastAIFile || (autoScrapedFiles.length > 0 ? autoScrapedFiles[0] : null);

      if (primaryFile) {
        try {
          console.log("[Markee Background] 🚀 Upload file lên Storage...", primaryFile.fileName);
          const safeFileName = String(primaryFile.fileName).replace(/[^a-zA-Z0-9.-]/g, "_");
          const uniqueFileName = `${Date.now()}_${safeFileName}`;

          // Decode base64 Data URL → Uint8Array (Service Worker không hỗ trợ fetch blob: URL)
          const b64String = primaryFile.base64.split(",")[1] || primaryFile.base64;
          const binStr = atob(b64String);
          const bytes = new Uint8Array(binStr.length);
          for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
          const blob = bytes;

          const uploadRes = await fetch(`${SUPABASE_URL}/storage/v1/object/chat_attachments/${uniqueFileName}`, {
            method: "POST",
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${SUPABASE_KEY}`,
              "Content-Type": primaryFile.mimeType || "application/octet-stream",
            },
            body: blob,
          });

          if (uploadRes.ok) {
            fileMetadata = {
              file_name: primaryFile.fileName,
              storage_path: uniqueFileName,
              mime_type: primaryFile.mimeType,
              size_bytes: primaryFile.size,
            };
            console.log("[Markee Background] ✅ Đẩy file đính kèm lên Storage thành công!");
          } else {
            const errText = await uploadRes.text();
            console.log("🟡 [WARN]", "[Markee Background] ⚠️ Upload file đính kèm thất bại:", errText);
          }
        } catch (err) {
          console.log("🔴 [ERROR]", "[Markee Background] ❌ Lỗi luồng upload file đính kèm:", err.message);
        }
      }

      // 2. ĐÓNG GÓI DỮ LIỆU ĐỂ LƯU VÀO SKILL_LIBRARY
      const payload = { ...message.data };
      if (payload.skill_type && payload.skill_type.toLowerCase() === "wip") {
        payload.skill_type = "wip";
      } else if (payload.skill_type) {
        payload.skill_type = payload.skill_type.toLowerCase();
      } else {
        payload.skill_type = "skill";
      }

      // N\u1ebfu B\u01b0\u1edbc 1 upload th\u00e0nh c\u00f4ng, nh\u00e9t th\u00f4ng tin file v\u00e0o c\u1ed9t jsonb d\u01b0\u1edbi d\u1ea1ng ARRAY
      // attached_file lu\u00f4n ph\u1ea3i t\u1ed3n t\u1ea1i trong payload (k\u1ec3 c\u1ea3 khi kh\u00f4ng c\u00f3 file) \u2014 tr\u00e1nh m\u1ea5t d\u1eef li\u1ec7u th\u00e2m l\u1eb7ng
      payload.attached_file = fileMetadata ? [fileMetadata] : [];

      // DEBUG: Ghi log payload để kiểm tra trước khi push
      console.log("[DEBUG] Payload gửi đi:", JSON.stringify(payload));

      // 3. PUSH DỮ LIỆU LÊN SUPABASE
      try {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/skill_library`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
            Prefer: "return=minimal",
          },
          body: JSON.stringify([payload]), // Lệnh Insert cần array
        });

        if (!res.ok) {
          const errDetail = await res.json().catch(() => ({}));
          throw new Error(`Supabase reject SKILL: ${JSON.stringify(errDetail)}`);
        }

        console.log("[Markee Background] 🎉 Đã đẩy dữ liệu (WIP Skill + File) lên Data thành công!");

        // Dọn dẹp biến tạm để không ám sang lần lưu sau
        lastAIFile = null;

        const savedFiles = message.autoScrapedFiles || [];
        const finalFileName = fileMetadata ? fileMetadata.file_name : savedFiles.length > 0 ? savedFiles[0].fileName || savedFiles[0].name : null;

        // Báo về UI hiển thị Popup Success + tín hiệu refresh danh sách
        chrome.tabs.sendMessage(sender.tab.id, {
          action: "SHOW_SUCCESS",
          title: payload.title,
          markdown_content: payload.markdown_content,
          isWipMode: message.isWipMode || false,
          projectId: payload.project_id || null,
          featureName: payload.feature_name || null,
          fileName: finalFileName,
          files: savedFiles,
        });

        // Gửi tín hiệu riêng để Content Script tự reload danh sách (không gọi hàm UI trong background)
        chrome.tabs.sendMessage(sender.tab.id, { action: "RELOAD_WIP_LIST" });

        // Tự động chuyển hướng về trang Usage của AI
        const hostUrl = sender.tab.url || "";
        let usageUrl = "";
        if (hostUrl.includes("claude.ai")) {
          usageUrl = "https://claude.ai/projects#settings/usage";
        } else if (hostUrl.includes("gemini.google.com")) {
          usageUrl = "https://gemini.google.com/u/0/usage?utm_source=app_launcher&utm_medium=owned&utm_campaign=base_all&pageId=none";
        }

        if (usageUrl !== "") {
          setTimeout(() => {
            chrome.tabs.create({ url: usageUrl, active: true });
          }, 1500);
        }

        sendResponse({ success: true, fileName: finalFileName, files: savedFiles });
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee Background] ❌ Lỗi luồng Push SKILL:", err.message);
        sendResponse({ success: false, error: err.message });
      }
    })();

    return true; // Phải có lệnh này để báo cho Chrome biết mình đang dùng Async
  }

  if (message.action === "GET_PROJECTS") {
    fetch(`${SUPABASE_URL}/rest/v1/projects?select=id,name,type,customer_id,customers(id,name)&type=eq.WIP_GLOBAL&order=name.asc`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        const projects = Array.isArray(data)
          ? data.map((p) => {
              let custName = "";
              if (p.customers) {
                custName = Array.isArray(p.customers) ? p.customers[0]?.name : p.customers.name;
              }
              return Object.assign({}, p, { customer_name: custName || "" });
            })
          : [];
        sendResponse({ projects });
      })
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Project:", err);
        sendResponse({ projects: [] });
      });
    return true;
  }

  if (message.action === "GET_DEPARTMENTS") {
    fetch(`${SUPABASE_URL}/rest/v1/departments?select=id,name&order=name.asc`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ departments: Array.isArray(data) ? data : [] }))
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Departments:", err);
        sendResponse({ departments: [] });
      });
    return true;
  }

  if (message.action === "GET_TEAMS") {
    let filter = "";
    if (message.departmentIds && Array.isArray(message.departmentIds) && message.departmentIds.length > 0) {
      filter = `&department_id=in.(${message.departmentIds.join(",")})`;
    } else if (message.departmentId) {
      const departmentId = Number(message.departmentId);
      if (Number.isInteger(departmentId)) {
        filter = `&department_id=eq.${departmentId}`;
      }
    }

    fetch(`${SUPABASE_URL}/rest/v1/teams?select=id,name,department_id${filter}&order=name.asc`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ teams: Array.isArray(data) ? data : [] }))
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Teams:", err);
        sendResponse({ teams: [] });
      });
    return true;
  }

  if (message.action === "GET_SKILLS") {
    const userId = message.userId;
    (async () => {
      try {
        let fetchUrl = "";
        let sortedSkillIds = null;
        const isWip = message.skillType === "wip";
        const typeFilter = isWip ? "skill_type=eq.wip" : "skill_type=neq.wip";
        const selectCols = isWip ? "id,title,markdown_content,feature_name,attached_file" : "id,title,markdown_content";

        if (message.filterType === "recent") {
          let recentUrl = `${SUPABASE_URL}/rest/v1/user_recent_skills?select=skill_id,used_at&order=used_at.desc&limit=20`;
          if (userId) {
            recentUrl += `&user_id=eq.${encodeURIComponent(userId)}`;
          }
          const recentRes = await fetch(recentUrl, {
            method: "GET",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
          });
          const recentData = await recentRes.json().catch(() => []);
          sortedSkillIds = Array.isArray(recentData) ? recentData.map((r) => r.skill_id) : [];

          if (sortedSkillIds.length === 0) {
            sendResponse({ skills: [], favoriteSkillIds: [] });
            return;
          }
          fetchUrl = `${SUPABASE_URL}/rest/v1/skill_library?select=${selectCols}&status=eq.approved&${typeFilter}&id=in.(${sortedSkillIds.join(",")})`;
        } else if (message.filterType === "favorite") {
          let favUrl = `${SUPABASE_URL}/rest/v1/user_favorite_skills?select=skill_id`;
          if (userId) {
            favUrl += `&user_id=eq.${encodeURIComponent(userId)}`;
          }
          const favRes = await fetch(favUrl, {
            method: "GET",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
          });
          const favData = await favRes.json().catch(() => []);
          const favIds = Array.isArray(favData) ? favData.map((f) => f.skill_id) : [];

          if (favIds.length === 0) {
            sendResponse({ skills: [], favoriteSkillIds: favIds });
            return;
          }
          fetchUrl = `${SUPABASE_URL}/rest/v1/skill_library?select=${selectCols}&status=eq.approved&${typeFilter}&id=in.(${favIds.join(",")})`;
        } else {
          const pageLimit = Number(message.limit) || (isWip ? 15 : 20);
          const pageOffset = Number(message.offset) || 0;
          fetchUrl = `${SUPABASE_URL}/rest/v1/skill_library?select=${selectCols}&status=eq.approved&${typeFilter}&order=id.desc&limit=${pageLimit}&offset=${pageOffset}`;
        }

        if (message.filterType !== "recent" && message.filterType !== "favorite") {
          if (message.skillIds && Array.isArray(message.skillIds)) {
            if (message.skillIds.length > 0) {
              fetchUrl += `&id=in.(${message.skillIds.join(",")})`;
            } else {
              sendResponse({ skills: [] });
              return;
            }
          }

          if (message.projectIds && Array.isArray(message.projectIds) && message.projectIds.length > 0) {
            fetchUrl += `&project_id=in.(${message.projectIds.join(",")})`;
          } else if (message.projectId) {
            fetchUrl += `&project_id=eq.${message.projectId}`;
          }

          if (message.departmentIds && Array.isArray(message.departmentIds) && message.departmentIds.length > 0) {
            fetchUrl += `&department_id=in.(${message.departmentIds.join(",")})`;
          } else if (message.departmentId) {
            fetchUrl += `&department_id=eq.${Number(message.departmentId)}`;
          }

          if (message.teamIds && Array.isArray(message.teamIds) && message.teamIds.length > 0) {
            fetchUrl += `&team_id=in.(${message.teamIds.join(",")})`;
          } else if (message.teamId) {
            fetchUrl += `&team_id=eq.${Number(message.teamId)}`;
          }
        }

        if (message.featureName) {
          fetchUrl += `&feature_name=ilike.*${encodeURIComponent(message.featureName)}*`;
        }

        if (message.keyword) {
          fetchUrl += `&title=ilike.*${encodeURIComponent(message.keyword)}*`;
        }

        let favCheckUrl = `${SUPABASE_URL}/rest/v1/user_favorite_skills?select=skill_id`;
        if (userId) {
          favCheckUrl += `&user_id=eq.${encodeURIComponent(userId)}`;
        }

        const [skillsRes, favRes] = await Promise.all([
          fetch(fetchUrl, {
            method: "GET",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
          }),
          fetch(favCheckUrl, {
            method: "GET",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
          }).catch(() => null),
        ]);

        const data = await skillsRes.json();
        const favData = favRes ? await favRes.json().catch(() => []) : [];
        const favSet = new Set(Array.isArray(favData) ? favData.map((f) => f.skill_id) : []);

        let skills = Array.isArray(data)
          ? data.map((s) => ({
              ...s,
              is_favorite: favSet.has(s.id),
            }))
          : [];

        if (sortedSkillIds && sortedSkillIds.length > 0) {
          skills.sort((a, b) => sortedSkillIds.indexOf(a.id) - sortedSkillIds.indexOf(b.id));
        }

        sendResponse({ skills, favoriteSkillIds: Array.from(favSet) });
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo Skill:", err);
        sendResponse({ skills: [] });
      }
    })();
    return true;
  }

  // --- SAVE RECENT SKILL (Lưu lịch sử dùng skill vào bảng user_recent_skills) ---
  if (message.action === "SAVE_RECENT_SKILL" || message.action === "RECORD_SKILL_USAGE") {
    const skillId = Number(message.skillId);
    const userId = message.userId;

    if (!skillId || !userId) {
      sendResponse({ success: false, error: "Thiếu skillId hoặc userId" });
      return true;
    }

    (async () => {
      try {
        // 1. Xóa bản ghi cũ nếu đã có (Tránh trùng lặp Primary Key user_id + skill_id)
        await fetch(`${SUPABASE_URL}/rest/v1/user_recent_skills?user_id=eq.${encodeURIComponent(userId)}&skill_id=eq.${skillId}`, {
          method: "DELETE",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
          },
        }).catch(() => null);

        // 2. Chèn bản ghi mới với mốc thời gian dùng được cập nhật mới nhất
        await fetch(`${SUPABASE_URL}/rest/v1/user_recent_skills`, {
          method: "POST",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
            "Content-Type": "application/json",
            Prefer: "return=minimal",
          },
          body: JSON.stringify({
            user_id: userId,
            skill_id: skillId,
            used_at: new Date().toISOString(),
          }),
        });
        sendResponse({ success: true });
      } catch (err) {
        console.log("🟡 [Markee] Lỗi lưu recent skill:", err);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  // --- ACTIONS XỬ LÝ FAVORITE SKILLS (Bảng user_favorite_skills) ---
  if (message.action === "GET_USER_FAVORITES") {
    const userId = message.userId;
    if (!userId) {
      sendResponse({ favoriteSkillIds: [] });
      return true;
    }
    fetch(`${SUPABASE_URL}/rest/v1/user_favorite_skills?select=skill_id&user_id=eq.${encodeURIComponent(userId)}`, {
      method: "GET",
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
    })
      .then((res) => res.json())
      .then((data) => {
        const ids = Array.isArray(data) ? data.map((d) => d.skill_id) : [];
        sendResponse({ favoriteSkillIds: ids });
      })
      .catch(() => sendResponse({ favoriteSkillIds: [] }));
    return true;
  }

  if (message.action === "TOGGLE_FAVORITE_SKILL") {
    const skillId = Number(message.skillId);
    const userId = message.userId;

    if (!skillId || !userId) {
      sendResponse({ success: false, error: "Thiếu skillId hoặc userId" });
      return true;
    }

    (async () => {
      try {
        // Kiểm tra xem đã yêu thích chưa
        const checkRes = await fetch(`${SUPABASE_URL}/rest/v1/user_favorite_skills?user_id=eq.${encodeURIComponent(userId)}&skill_id=eq.${skillId}`, {
          method: "GET",
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
        });
        const existing = await checkRes.json();
        const isCurrentlyFav = Array.isArray(existing) && existing.length > 0;

        if (isCurrentlyFav) {
          // Hủy yêu thích (DELETE)
          await fetch(`${SUPABASE_URL}/rest/v1/user_favorite_skills?user_id=eq.${encodeURIComponent(userId)}&skill_id=eq.${skillId}`, {
            method: "DELETE",
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
          });
          sendResponse({ success: true, isFavorite: false });
        } else {
          // Thêm yêu thích (POST)
          await fetch(`${SUPABASE_URL}/rest/v1/user_favorite_skills`, {
            method: "POST",
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${SUPABASE_KEY}`,
              "Content-Type": "application/json",
              Prefer: "return=minimal",
            },
            body: JSON.stringify({ user_id: userId, skill_id: skillId }),
          });
          sendResponse({ success: true, isFavorite: true });
        }
      } catch (err) {
        console.log("🟡 [Markee] Lỗi toggle favorite skill:", err);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.action === "GET_CUSTOMERS") {
    fetch(`${SUPABASE_URL}/rest/v1/customers?select=id,name&order=name.asc`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ customers: Array.isArray(data) ? data : [] }))
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Customers:", err);
        sendResponse({ customers: [] });
      });
    return true;
  }

  if (message.action === "GET_PROJECTS_BY_CUSTOMER") {
    const customerId = message.customerId;
    fetch(`${SUPABASE_URL}/rest/v1/projects?select=id,name,customer_id,customers(id,name)&customer_id=eq.${customerId}&order=name.asc`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        const projects = Array.isArray(data)
          ? data.map((p) => {
              let custName = "";
              if (p.customers) {
                custName = Array.isArray(p.customers) ? p.customers[0]?.name : p.customers.name;
              }
              return Object.assign({}, p, { customer_name: custName || "" });
            })
          : [];
        sendResponse({ projects });
      })
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Projects by Customer:", err);
        sendResponse({ projects: [] });
      });
    return true;
  }

  if (message.action === "GET_FAVORITE_PROJECT_IDS") {
    getUserEmail().then((email) => {
      if (!email || email === "Unknown") {
        return sendResponse({ favoriteProjectIds: [] });
      }
      const encodedEmail = encodeURIComponent(email);
      fetch(`${SUPABASE_URL}/rest/v1/user_favorite_projects?select=project_id&user_email=eq.${encodedEmail}`, {
        method: "GET",
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          const favoriteProjectIds = Array.isArray(data) ? data.map((item) => item.project_id) : [];
          sendResponse({ favoriteProjectIds });
        })
        .catch((err) => {
          console.log("🔴 [ERROR]", "[Markee] Lỗi lấy danh sách favorite_project_ids:", err);
          sendResponse({ favoriteProjectIds: [] });
        });
    });
    return true;
  }

  if (message.action === "GET_FAVORITE_PROJECTS") {
    getUserEmail().then((email) => {
      if (!email || email === "Unknown") {
        return sendResponse({ projects: [] });
      }
      const encodedEmail = encodeURIComponent(email);
      fetch(`${SUPABASE_URL}/rest/v1/user_favorite_projects?select=project_id,projects(*,customers(name))&user_email=eq.${encodedEmail}`, {
        method: "GET",
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          const projects = Array.isArray(data)
            ? data
                .map((item) => {
                  const p = item.projects;
                  if (!p) return null;
                  let custName = "";
                  if (p.customers) {
                    custName = Array.isArray(p.customers) ? p.customers[0]?.name : p.customers.name;
                  }
                  return Object.assign({}, p, { customer_name: custName || "" });
                })
                .filter(Boolean)
            : [];
          sendResponse({ projects });
        })
        .catch((err) => {
          console.log("🔴 [ERROR]", "[Markee] Lỗi lấy dự án ưu thích:", err);
          sendResponse({ projects: [] });
        });
    });
    return true;
  }

  if (message.action === "TOGGLE_FAVORITE_PROJECT") {
    getUserEmail().then(async (email) => {
      if (!email || email === "Unknown") {
        return sendResponse({ success: false, error: "Không tìm thấy email người dùng." });
      }
      const projectId = Number(message.projectId);
      const isFav = Boolean(message.isFavorite);
      const encodedEmail = encodeURIComponent(email);

      try {
        if (isFav) {
          const delRes = await fetch(`${SUPABASE_URL}/rest/v1/user_favorite_projects?user_email=eq.${encodedEmail}&project_id=eq.${projectId}`, {
            method: "DELETE",
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${SUPABASE_KEY}`,
            },
          });
          sendResponse({ success: delRes.ok, isFavorite: false });
        } else {
          const addRes = await fetch(`${SUPABASE_URL}/rest/v1/user_favorite_projects`, {
            method: "POST",
            headers: {
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${SUPABASE_KEY}`,
              "Content-Type": "application/json",
              Prefer: "return=representation",
            },
            body: JSON.stringify({
              user_email: email,
              project_id: projectId,
            }),
          });
          sendResponse({ success: addRes.ok, isFavorite: true });
        }
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee] Lỗi toggle favorite project:", err);
        sendResponse({ success: false, error: err.message });
      }
    });
    return true;
  }

  if (message.action === "GET_PROJECT_BY_ID") {
    const projectId = Number(message.projectId);
    fetch(`${SUPABASE_URL}/rest/v1/projects?select=id,name,master_summary&id=eq.${projectId}`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ project: data?.[0] || null }))
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo Project by ID:", err);
        sendResponse({ project: null });
      });
    return true;
  }

  if (message.action === "GET_PROJECT_FEATURES") {
    const projectId = Number(message.projectId);
    if (!Number.isInteger(projectId) || projectId <= 0) {
      sendResponse({ features: [] });
      return true;
    }

    fetch(`${SUPABASE_URL}/rest/v1/skill_library?select=feature_name&project_id=eq.${projectId}&feature_name=not.is.null`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        if (!Array.isArray(data)) {
          sendResponse({ features: [] });
          return;
        }
        const uniqueFeatures = Array.from(new Set(data.map((item) => (item && item.feature_name ? String(item.feature_name).trim() : "")).filter(Boolean))).sort();
        sendResponse({ features: uniqueFeatures });
      })
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo danh sách Features:", err);
        sendResponse({ features: [] });
      });
    return true;
  }

  if (message.action === "GET_PROJECT_SHARE_LINK") {
    (async () => {
      const projectId = Number(message.projectId);
      if (!Number.isInteger(projectId) || projectId <= 0) {
        sendResponse({ success: false, error: "Invalid projectId" });
        return;
      }

      // Dùng Supabase trực tiếp — tránh CORS khi gọi từ chrome-extension://
      try {
        const checkRes = await fetch(`${SUPABASE_URL}/rest/v1/projects?select=share_token&id=eq.${projectId}`, {
          method: "GET",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
          },
        });

        if (!checkRes.ok) {
          throw new Error(`Supabase select project failed: ${checkRes.statusText}`);
        }

        const projectData = await checkRes.json();
        let token = projectData?.[0]?.share_token;

        if (!token) {
          token = crypto.randomUUID();
          const updateRes = await fetch(`${SUPABASE_URL}/rest/v1/projects?id=eq.${projectId}`, {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_KEY,
              Authorization: `Bearer ${SUPABASE_KEY}`,
              Prefer: "return=representation",
            },
            body: JSON.stringify({ share_token: token }),
          });

          if (!updateRes.ok) {
            throw new Error(`Supabase patch project failed: ${updateRes.statusText}`);
          }
        }

        let shareUrl = `https://aiskill.markeeai.com/shared/project/${token}`;

        // Append query params: ?feature=<featureName>&wip=<wipId>
        const queryParts = [];
        if (message.featureName && String(message.featureName).trim()) {
          queryParts.push("feature=" + encodeURIComponent(String(message.featureName).trim()));
        }
        if (message.wipId) {
          queryParts.push("wip=" + encodeURIComponent(String(message.wipId)));
        }
        if (queryParts.length > 0) {
          shareUrl += "?" + queryParts.join("&");
        }

        sendResponse({ success: true, shareUrl });
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee Background] Lỗi xử lý share-link:", err.message);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.action === "GET_SUMMARIES") {
    const projectId = Number(message.projectId);
    if (!Number.isInteger(projectId) || projectId <= 0) {
      sendResponse({ summaries: [] });
      return true;
    }

    fetch(`${SUPABASE_URL}/rest/v1/projects?select=master_summary&id=eq.${projectId}`, {
      method: "GET",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        let summaries = [];
        try {
          const raw = Array.isArray(data) && data[0] ? data[0].master_summary : null;
          if (raw) {
            const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
            summaries = Array.isArray(parsed) ? parsed : [];
          }
        } catch (err) {
          console.log("🔴 [ERROR]", "[Markee] Lỗi parse master_summary:", err);
          summaries = [];
        }
        sendResponse({ summaries });
      })
      .catch((err) => {
        console.log("🔴 [ERROR]", "[Markee] Lỗi kéo Summaries:", err);
        sendResponse({ summaries: [] });
      });
    return true;
  }

  if (message.action === "DELETE_WIP") {
    (async () => {
      const wipId = message.wipId;
      if (!wipId) {
        sendResponse({ ok: false, error: "Thiếu wipId" });
        return;
      }

      try {
        // Bước 1: Xóa các bản ghi user_likes liên quan trước để tránh lỗi FK 23503
        const likesRes = await fetch(`${SUPABASE_URL}/rest/v1/user_likes?skill_id=eq.${wipId}`, {
          method: "DELETE",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
            Prefer: "return=minimal",
          },
        });
        if (!likesRes.ok) {
          const likesErr = await likesRes.text().catch(() => "");
          console.log("🟡 [WARN]", "[Markee] Xóa user_likes thất bại (tiếp tục):", likesErr);
        } else {
          console.log("[Markee] ✅ Đã dọn sạch user_likes cho WIP:", wipId);
        }

        // Bước 2: Xóa bản ghi trong skill_library
        const deleteRes = await fetch(`${SUPABASE_URL}/rest/v1/skill_library?id=eq.${wipId}`, {
          method: "DELETE",
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
            Prefer: "return=minimal",
          },
        });

        if (!deleteRes.ok) {
          const deleteErr = await deleteRes.text().catch(() => "");
          throw new Error(`Xóa WIP thất bại: ${deleteErr}`);
        }

        console.log("[Markee] ✅ Đã xóa WIP thành công:", wipId);
        sendResponse({ ok: true });
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee] Lỗi xóa WIP:", err.message);
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.action === "CLOSE_CURRENT_TAB") {
    chrome.tabs.remove(sender.tab.id);
  }

  if (message.action === "SAVE_USAGE_STATS") {
    fetch(`${SUPABASE_URL}/rest/v1/ai_usage_stats`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        Prefer: "return=minimal",
      },
      body: JSON.stringify([message.data]),
    }).catch((err) => console.log("🔴 [ERROR]", "[Markee Background] Lỗi lưu Usage:", err));
  }

  // Tải file đính kèm từ Supabase Storage (tránh CORS từ Content Script)
  if (message.action === "FETCH_ATTACHMENT") {
    (async () => {
      try {
        let storagePath = message.storagePath;
        let mimeType = message.mimeType;
        let fileName = message.fileName;

        if (message.skill) {
          const skill = message.skill;
          let fileInfo = Array.isArray(skill.attached_file) ? skill.attached_file[0] : skill.attached_file;
          if (fileInfo) fileInfo.file_name = fileInfo.file_name || fileInfo.name;
          if (!fileInfo || !fileInfo.storage_path) {
            console.error("Lỗi: Không có storage_path");
            sendResponse({ ok: false, error: "Lỗi: Không có storage_path" });
            return;
          }
          storagePath = fileInfo.storage_path;
          mimeType = fileInfo.mime_type || fileInfo.mimeType || mimeType;
          fileName = fileInfo.file_name || fileName;
        }

        if (!storagePath) {
          sendResponse({ ok: false, error: "Thiếu storagePath" });
          return;
        }
        const fileUrl = `${SUPABASE_URL}/storage/v1/object/public/chat_attachments/${storagePath}`;
        const res = await fetch(fileUrl, {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
          },
        });
        if (!res.ok) {
          throw new Error(`Fetch attachment failed: ${res.status} ${res.statusText}`);
        }
        const buffer = await res.arrayBuffer();
        // Dùng hàm chunk để tránh lỗi "Maximum call stack size exceeded" khi file > 65KB
        const base64 = uint8ArrayToBase64(new Uint8Array(buffer));
        sendResponse({
          ok: true,
          base64,
          mimeType: mimeType || res.headers.get("Content-Type") || "application/octet-stream",
          fileName: fileName || storagePath.split("/").pop(),
        });
      } catch (err) {
        console.log("🔴 [ERROR]", "[Markee Background] Lỗi tải file đính kèm:", err.message);
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }
});
